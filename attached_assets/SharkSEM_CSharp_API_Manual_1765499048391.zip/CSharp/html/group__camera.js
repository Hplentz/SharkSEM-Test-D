var group__camera =
[
    [ "SharkSEM.Commands.CameraDisable", "group__camera.html#gad65f8b54e9f14829b3c875164b180905", null ],
    [ "SharkSEM.Commands.CameraEnable", "group__camera.html#ga45ae86d9af694b38b3417a3a59ee1ef6", null ],
    [ "SharkSEM.Commands.CameraEnum", "group__camera.html#gaec8511b2c77208ca62385bb477c2658c", null ],
    [ "SharkSEM.Commands.CameraGetStatus", "group__camera.html#ga4baaeca94cbb10efeddde8b455f320fa", null ],
    [ "SharkSEM.Commands.CameraGetStatus", "group__camera.html#ga1783af56128e579b0be6e3a4103d3b79", null ],
    [ "SharkSEM.Commands.FetchCameraImage", "group__camera.html#ga60f037a06f8c4d1e1564b46ad4cd34ec", null ]
];