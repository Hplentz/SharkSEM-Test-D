var searchData=
[
  ['image_20geometry_0',['image geometry',['../group__fib_geom.html',1,'FIB Image Geometry'],['../group__sem_geometry.html',1,'SEM Image Geometry']]],
  ['indication_1',['Progress Indication',['../group__progress.html',1,'']]],
  ['injection_20system_2',['GIS - Gas Injection System',['../group___gis.html',1,'']]],
  ['input_20channels_20and_20detectors_3',['input channels and detectors',['../group__fib_detectors.html',1,'FIB Input Channels and Detectors'],['../group__sem_detector.html',1,'SEM Input Channels And Detectors']]],
  ['input_20dialog_4',['Input dialog',['../group__input.html',1,'']]],
  ['interface_5',['Power interface',['../group__power.html',1,'']]]
];
