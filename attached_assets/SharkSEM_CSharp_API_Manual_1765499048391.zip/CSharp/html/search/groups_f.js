var searchData=
[
  ['rca_20rotating_20chord_20algorithm_0',['RCA - Rotating Chord Algorithm',['../group__rca.html',1,'']]],
  ['rotating_20chord_20algorithm_1',['RCA - Rotating Chord Algorithm',['../group__rca.html',1,'']]]
];
