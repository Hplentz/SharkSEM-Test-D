var indexSectionsWithContent =
{
  0: "12abcdefghilmnopqrstvx",
  1: "c",
  2: "s",
  3: "c",
  4: "acdefghimnprstv",
  5: "12acdefghilmnoprstv",
  6: "abcdflmoprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Modules",
  6: "Pages"
};

