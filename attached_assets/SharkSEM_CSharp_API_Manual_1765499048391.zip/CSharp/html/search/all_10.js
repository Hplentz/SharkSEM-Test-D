var searchData=
[
  ['queue_0',['queue',['../command_processing.html#multipleQueue',1,'Multiple queue'],['../command_processing.html#singleQueue',1,'Single queue']]]
];
