var searchData=
[
  ['advanced_20functions_0',['List of Advanced functions',['../advanced_list.html',1,'ext']]],
  ['algorithm_1',['Rotating Chord Algorithm',['../rca_desc.html',1,'']]],
  ['automation_20functions_2',['List of Automation functions',['../automation_list.html',1,'ext']]]
];
