var searchData=
[
  ['management_0',['Session management',['../session_mgmt.html',1,'']]],
  ['message_20structure_1',['Message Structure',['../message_structure.html',1,'']]]
];
