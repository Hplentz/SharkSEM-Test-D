var searchData=
[
  ['rca_20functions_0',['List of RCA functions',['../rca_list.html',1,'ext']]],
  ['rotating_20chord_20algorithm_1',['Rotating Chord Algorithm',['../rca_desc.html',1,'']]]
];
