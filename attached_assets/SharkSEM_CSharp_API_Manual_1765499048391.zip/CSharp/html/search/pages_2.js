var searchData=
[
  ['chord_20algorithm_0',['Rotating Chord Algorithm',['../rca_desc.html',1,'']]],
  ['command_20processing_1',['Command Processing',['../command_processing.html',1,'']]]
];
