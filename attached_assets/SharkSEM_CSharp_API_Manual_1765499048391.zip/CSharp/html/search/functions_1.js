var searchData=
[
  ['cameradisable_0',['CameraDisable',['../group__camera.html#gad65f8b54e9f14829b3c875164b180905',1,'SharkSEM::Commands']]],
  ['cameraenable_1',['CameraEnable',['../group__camera.html#ga45ae86d9af694b38b3417a3a59ee1ef6',1,'SharkSEM::Commands']]],
  ['cameraenum_2',['CameraEnum',['../group__camera.html#gaec8511b2c77208ca62385bb477c2658c',1,'SharkSEM::Commands']]],
  ['cameragetstatus_3',['cameragetstatus',['../group__camera.html#ga4baaeca94cbb10efeddde8b455f320fa',1,'SharkSEM.Commands.CameraGetStatus(this Connection Conn, int Index, out int IsEnabled, out double Zoom, out double Fps, out int Compression)'],['../group__camera.html#ga1783af56128e579b0be6e3a4103d3b79',1,'SharkSEM.Commands.CameraGetStatus(this Connection Conn, out int IsEnabled, out double Zoom, out double Fps, out int Compression)']]],
  ['chamberled_4',['ChamberLed',['../group__misc.html#ga92d740d250d8637cf6a1f7a8f49d65df',1,'SharkSEM::Commands']]]
];
