var group__presets =
[
    [ "SharkSEM.Commands.PresetEnum", "group__presets.html#ga917e9264bc4b6a85b2a1fa01d467a8ea", null ],
    [ "SharkSEM.Commands.PresetEnum", "group__presets.html#gae2935083d06fa0dc8661e8becea3ec4b", null ],
    [ "SharkSEM.Commands.PresetSet", "group__presets.html#ga72c45849ffef53bec5d3014d469c5f60", null ],
    [ "SharkSEM.Commands.PresetSetEx", "group__presets.html#gad1af696e93422324666412be507a53c9", null ],
    [ "SharkSEM.Commands.PresetUpdate", "group__presets.html#ga695526b9f7be645b212e9608f2a7a982", null ]
];