var group__misc =
[
    [ "SharkSEM.Commands.ChamberLed", "group__misc.html#ga92d740d250d8637cf6a1f7a8f49d65df", null ],
    [ "SharkSEM.Commands.Delay", "group__misc.html#gabf8672674bfa9a7452d06d5f50edd825", null ],
    [ "SharkSEM.Commands.GetDeviceParams", "group__misc.html#ga6ae0c6b1090509f327fe1abeb5b9482a", null ],
    [ "SharkSEM.Commands.GetUPSStatus", "group__misc.html#gace4cc8dc0e8bb0fd4fdc7c9b6e53b319", null ],
    [ "SharkSEM.Commands.IsBusy", "group__misc.html#gad5aab3cac985490b4327ff59c9f45d63", null ],
    [ "SharkSEM.Commands.IsLicenseValid", "group__misc.html#gaef322039e7763a3b40ed38001998d614", null ]
];