var group__nose =
[
    [ "SharkSEM.Commands.NoseCalibrate", "group__nose.html#ga5bb0c8c52298573df227dfdb2c51726f", null ],
    [ "SharkSEM.Commands.NoseEnum", "group__nose.html#gabf6e0054bfa06255f8cecc34b3256c21", null ],
    [ "SharkSEM.Commands.NoseGetConfig", "group__nose.html#ga2df6e5e6b3bbec82811a6116b7837b3e", null ],
    [ "SharkSEM.Commands.NoseGetPosition", "group__nose.html#gaf16a05aa3fc8b21139e2d7106b16cd69", null ],
    [ "SharkSEM.Commands.NoseIsBusy", "group__nose.html#ga45af7a892f96d4379b55db23b6d1192d", null ],
    [ "SharkSEM.Commands.NoseIsCalib", "group__nose.html#ga1a31a96ea112307702af319e1d2a4db3", null ],
    [ "SharkSEM.Commands.NoseMoveToMem", "group__nose.html#ga71878fb82262905b01822eedbbf1fc8a", null ],
    [ "SharkSEM.Commands.NoseMoveToPos", "group__nose.html#ga28d040f6087c42c94879d96477a0d17e", null ],
    [ "SharkSEM.Commands.NoseMoveToPos", "group__nose.html#gae2af363f03c90ed58db0b41f8d1013ef", null ],
    [ "SharkSEM.Commands.NoseMoveToPos", "group__nose.html#ga09a44d1217721e434d12a429a49d3333", null ],
    [ "SharkSEM.Commands.NoseStop", "group__nose.html#ga7da550a943e785fa1c473839e65e9f45", null ],
    [ "SharkSEM.Commands.NoseTestMoveMem", "group__nose.html#ga58b067c72aea981affbda5fb3c9b76fb", null ],
    [ "SharkSEM.Commands.NoseTestMovePos", "group__nose.html#ga349d588e3c37a5d34516f317f93b27bd", null ],
    [ "SharkSEM.Commands.NoseTestMovePos", "group__nose.html#ga0f86cf8db10f038afb48b4575dbe480f", null ],
    [ "SharkSEM.Commands.NoseTestMovePos", "group__nose.html#gaef4fe69424d9c8e0583ddac3aef0a8e9", null ]
];