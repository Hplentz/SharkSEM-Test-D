var group__vacuum =
[
    [ "SharkSEM.Commands.VacAptEnum", "group__vacuum.html#ga7a436f2c09cc2a894764951734f06ec6", null ],
    [ "SharkSEM.Commands.VacGetPressure", "group__vacuum.html#ga7a70fb21bdc39d835eadd3c7df0ba84a", null ],
    [ "SharkSEM.Commands.VacGetStatus", "group__vacuum.html#ga5542ddbfccd2a9f67b6513b489c0b9af", null ],
    [ "SharkSEM.Commands.VacGetVPMode", "group__vacuum.html#gafe2f83c9858f5fb26efdec78ac1d11e2", null ],
    [ "SharkSEM.Commands.VacGetVPPress", "group__vacuum.html#gaf4734da129dc205b23b405346f8d2337", null ],
    [ "SharkSEM.Commands.VacPump", "group__vacuum.html#ga3b5eeea8d3a2dcb0796821e063dd7c66", null ],
    [ "SharkSEM.Commands.VacSetVPMode", "group__vacuum.html#gaf19c8a24020953259124e7a79a6b2f17", null ],
    [ "SharkSEM.Commands.VacSetVPMode", "group__vacuum.html#gaa43bcd223f22e0ea66dc37c8b1e08ee5", null ],
    [ "SharkSEM.Commands.VacSetVPMode", "group__vacuum.html#gac4d16150e7f75e2f0757e861e876d158", null ],
    [ "SharkSEM.Commands.VacSetVPPress", "group__vacuum.html#gad71971703af2d5f96ad716c82c4b4f5e", null ],
    [ "SharkSEM.Commands.VacVent", "group__vacuum.html#ga661b85da054b3c09d52f94bc06203407", null ]
];