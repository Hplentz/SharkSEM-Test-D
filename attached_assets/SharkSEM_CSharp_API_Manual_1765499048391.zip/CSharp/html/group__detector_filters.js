var group__detector_filters =
[
    [ "SharkSEM.Commands.DetFltEnable", "group__detector_filters.html#gab48a3a0fa9b243ffac13b54198a52ada", null ],
    [ "SharkSEM.Commands.DetFltEnum", "group__detector_filters.html#ga091e854654e2de5870347dd4e3d9b14f", null ],
    [ "SharkSEM.Commands.DetFltGet", "group__detector_filters.html#ga14a1e738c0fe255e3e21eead726a77cc", null ],
    [ "SharkSEM.Commands.DetFltGetLimits", "group__detector_filters.html#ga487a2fbd8bc5218c44b695419010eb73", null ],
    [ "SharkSEM.Commands.DetFltSet", "group__detector_filters.html#gad02bae170231daf7f602438ce17a8005", null ]
];