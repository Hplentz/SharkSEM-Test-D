var group__sem_detector =
[
    [ "SharkSEM.Commands.DtAutoSignal", "group__sem_detector.html#gae87e4a858e3caa9559bcdcf0fa5c3a6e", null ],
    [ "SharkSEM.Commands.DtAutoSignal", "group__sem_detector.html#ga215324c991653db8efb3101d95f4b1e9", null ],
    [ "SharkSEM.Commands.DtEnable", "group__sem_detector.html#ga8d4141613166bddc8af7a670bd6105cb", null ],
    [ "SharkSEM.Commands.DtEnable", "group__sem_detector.html#gad1b753ed889e96ae28b61074592d8f82", null ],
    [ "SharkSEM.Commands.DtEnumDetectors", "group__sem_detector.html#ga13b0c0e5c4cf4ccf7b732f5d1332201e", null ],
    [ "SharkSEM.Commands.DtGetChannels", "group__sem_detector.html#gae0b9ed0e939fb0bd4aed04324f77f89b", null ],
    [ "SharkSEM.Commands.DtGetEnabled", "group__sem_detector.html#gae2585dad5f1c4b179e2d15d0b2b7f45c", null ],
    [ "SharkSEM.Commands.DtGetGainBlack", "group__sem_detector.html#ga103599c0068c03efeed99bcea93fede8", null ],
    [ "SharkSEM.Commands.DtGetSelected", "group__sem_detector.html#ga550d72f196e966682e02409d645db00f", null ],
    [ "SharkSEM.Commands.DtGetSESuitable", "group__sem_detector.html#gabd32d64f17814909d5313cf01116dbad", null ],
    [ "SharkSEM.Commands.DtSelect", "group__sem_detector.html#ga154fe295aaa7da1c86732b483f9c5466", null ],
    [ "SharkSEM.Commands.DtSetGainBlack", "group__sem_detector.html#gac0e581a6ee8b9f83a160b77186d7142d", null ],
    [ "SharkSEM.Commands.DtStateEnum", "group__sem_detector.html#gaa73b94112f18aa149b8553f1bc47d126", null ],
    [ "SharkSEM.Commands.DtStateGet", "group__sem_detector.html#ga34325979f25250cf8ae53dfac1a24505", null ],
    [ "SharkSEM.Commands.DtStateSet", "group__sem_detector.html#ga5ab2b80d5f51382b3d824837235781b3", null ]
];