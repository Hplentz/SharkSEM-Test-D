var group__power =
[
    [ "SharkSEM.Commands.PowerStateEnum", "group__power.html#gaa15538d204249b764b7e437684c673a2", null ],
    [ "SharkSEM.Commands.PowerStateGet", "group__power.html#gaa71b95b80c5e2e4372535bbad897005d", null ],
    [ "SharkSEM.Commands.PowerStateSet", "group__power.html#ga5cd4099a0c11888e3320bb82141b158e", null ]
];