var group__fib =
[
    [ "FIB Input Channels and Detectors", "group__fib_detectors.html", "group__fib_detectors" ],
    [ "FIB High Voltage", "group__fib_h_v.html", "group__fib_h_v" ],
    [ "FIB Optics", "group__fib_optics.html", "group__fib_optics" ],
    [ "FIB Image Geometry", "group__fib_geom.html", "group__fib_geom" ],
    [ "FIB Centering", "group__fib_centering.html", "group__fib_centering" ],
    [ "FIB Presets", "group__fib_preset.html", "group__fib_preset" ],
    [ "FIB Scanning", "group__fib_scan.html", "group__fib_scan" ]
];