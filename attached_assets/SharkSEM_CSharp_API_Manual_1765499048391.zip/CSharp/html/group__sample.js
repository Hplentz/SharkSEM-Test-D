var group__sample =
[
    [ "SharkSEM.Commands.SmplEnum", "group__sample.html#ga6e06ff6a86b8e28890479f2caffa7a1c", null ],
    [ "SharkSEM.Commands.SmplGetCount", "group__sample.html#ga05b349a494270384e0f8382701b49500", null ],
    [ "SharkSEM.Commands.SmplGetHldrName", "group__sample.html#gafae20398889496a75cb04dfe0f6c7e98", null ],
    [ "SharkSEM.Commands.SmplGetId", "group__sample.html#gaa5963253a3104416cb4bc5aa2d7b272e", null ],
    [ "SharkSEM.Commands.SmplGetLabel", "group__sample.html#gaf53065d50d12168858dbc0c2ae2ee392", null ],
    [ "SharkSEM.Commands.SmplGetPosition", "group__sample.html#ga8a940b1a999c62fb7d1169759419e8dd", null ],
    [ "SharkSEM.Commands.SmplGetShape", "group__sample.html#gaf4c19e02d3ce00c8178b49af23d0abfb", null ],
    [ "SharkSEM.Commands.SmplGetType", "group__sample.html#ga9712dddecbdd1a8cef8a6a985f0f702e", null ],
    [ "SharkSEM.Commands.SmplSetLabel", "group__sample.html#ga369cf228a37d41e6fbe823413caadea3", null ]
];