var group__sem_gui =
[
    [ "SharkSEM.Commands.GUIGetCurrDets", "group__sem_gui.html#ga5346b92768caf801fa1a512e76450229", null ],
    [ "SharkSEM.Commands.GUIGetScanning", "group__sem_gui.html#ga063a2011037390c7a58e7acd6d617aa1", null ],
    [ "SharkSEM.Commands.GUIResetLUT", "group__sem_gui.html#gaf1f08d2716a9b838cbeeddccf2b87bbf", null ],
    [ "SharkSEM.Commands.GUISetLiveAS", "group__sem_gui.html#ga76d73b4a83b7d211dfd05aa6eeba0a30", null ],
    [ "SharkSEM.Commands.GUISetScanning", "group__sem_gui.html#ga4b7533fac3278ace9a50674373b8caf9", null ]
];