var group__communication =
[
    [ "SharkSEM.Commands.TcpGetDevice", "group__communication.html#ga7fd7274f81ecbc306a4bad66bf71ca04", null ],
    [ "SharkSEM.Commands.TcpGetModel", "group__communication.html#ga709cb44a4d15ef989fcc04f83dfca13b", null ],
    [ "SharkSEM.Commands.TcpGetSWVersion", "group__communication.html#ga18faf05a4885f53a4ba7414c12cc5844", null ],
    [ "SharkSEM.Commands.TcpGetVersion", "group__communication.html#ga8dc4710cba70d6be22b0ec77038d711b", null ]
];