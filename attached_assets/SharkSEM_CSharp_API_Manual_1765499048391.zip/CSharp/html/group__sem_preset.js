var group__sem_preset =
[
    [ "SharkSEM.Commands.SemEnumPresets", "group__sem_preset.html#gadd5e99dc63ea4abe608c3b05492a4177", null ],
    [ "SharkSEM.Commands.SemPresetUpdate", "group__sem_preset.html#gad1a29f64949c2e66e7137fd6adda3ad1", null ],
    [ "SharkSEM.Commands.SemSetPreset", "group__sem_preset.html#ga0e42afc7073a12b7666705dc7143833f", null ],
    [ "SharkSEM.Commands.SemSetPresetEx", "group__sem_preset.html#ga39f59d77abef1a7fa82749fe44635777", null ]
];