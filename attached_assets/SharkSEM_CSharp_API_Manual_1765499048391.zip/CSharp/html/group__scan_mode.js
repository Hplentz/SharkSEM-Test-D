var group__scan_mode =
[
    [ "SharkSEM.Commands.SMEnumModes", "group__scan_mode.html#ga7f58cdc7be7882f05902ef8147768f23", null ],
    [ "SharkSEM.Commands.SMGetMode", "group__scan_mode.html#ga47fea98602b901dc03ba090ecfef0d82", null ],
    [ "SharkSEM.Commands.SMGetPivotPos", "group__scan_mode.html#ga3cf676d4a00f2271d763e662f54813c2", null ],
    [ "SharkSEM.Commands.SMSetMode", "group__scan_mode.html#ga9c27f35356cc8bdcaf86ea7c81a92e74", null ]
];