var group__fib_preset =
[
    [ "SharkSEM.Commands.FibEnumPresets", "group__fib_preset.html#gaa96f482b0af962ad791576cb323fbbc9", null ],
    [ "SharkSEM.Commands.FibPresetUpdate", "group__fib_preset.html#ga40ca154004d87747c786a661cf04771b", null ],
    [ "SharkSEM.Commands.FibSetPreset", "group__fib_preset.html#gaa94d7c04ab9bebec79a315c2098009ee", null ],
    [ "SharkSEM.Commands.FibSetPresetEx", "group__fib_preset.html#gaf2ad1b39804654426c560a5bccb47df3", null ]
];