var group__eds =
[
    [ "SharkSEM.Commands.EdsAcquire", "group__eds.html#ga6586dcbf89796f0e0b9fc1b2156d0852", null ],
    [ "SharkSEM.Commands.EdsAcquire", "group__eds.html#ga81fac65b800f710d3a1b82fac2d4e07e", null ],
    [ "SharkSEM.Commands.EdsAutoId", "group__eds.html#gaaaf6b39bf0fb040d5f9568640a9f4263", null ],
    [ "SharkSEM.Commands.EdsEnumProfiles", "group__eds.html#ga9c88193db1e576610764a0fc9cd95c48", null ],
    [ "SharkSEM.Commands.EdsGetSpectrum", "group__eds.html#ga346c52225b58cd70b193677cfe373b87", null ],
    [ "SharkSEM.Commands.EdsGetState", "group__eds.html#ga69b321affb0c9da98690dec2cb3f227f", null ],
    [ "SharkSEM.Commands.EdsInit", "group__eds.html#ga4c7eebeb613f295d8cdb5b9df6ecb048", null ],
    [ "SharkSEM.Commands.EdsQuantify", "group__eds.html#ga2332a215f5677d553c900f2931834109", null ],
    [ "SharkSEM.Commands.EdsStopAcq", "group__eds.html#gabc80e35fee6d5ae832146d7b6e087f68", null ]
];