var group__sem_geometry =
[
    [ "SharkSEM.Commands.EnumGeometries", "group__sem_geometry.html#gae60e47484c2778b04f78e87693c5aaba", null ],
    [ "SharkSEM.Commands.Get3DBeam", "group__sem_geometry.html#ga26887b94862ee6ac5db2cbdc90f60d62", null ],
    [ "SharkSEM.Commands.GetGeometry", "group__sem_geometry.html#ga1f0382178542707d3edb92500a06b377", null ],
    [ "SharkSEM.Commands.GetGeomLimits", "group__sem_geometry.html#gae99ce87955b5297b3a3f095d420c1855", null ],
    [ "SharkSEM.Commands.GetImageRot", "group__sem_geometry.html#ga85c477a141e4c180e8ea372f3f7c33eb", null ],
    [ "SharkSEM.Commands.GetImageShift", "group__sem_geometry.html#ga36ba33f76b99ea549eef0f69b3079f15", null ],
    [ "SharkSEM.Commands.Set3DBeam", "group__sem_geometry.html#ga6a98c4930a7f7f2e1939bf5eaa43bdd4", null ],
    [ "SharkSEM.Commands.SetGeometry", "group__sem_geometry.html#ga6af701167c1c858631b8e30f6316f4ed", null ],
    [ "SharkSEM.Commands.SetImageRot", "group__sem_geometry.html#ga5e810d064701e794544fdd663307ce99", null ],
    [ "SharkSEM.Commands.SetImageShift", "group__sem_geometry.html#ga86ea6a861f6a9443254962b62fa802f7", null ]
];