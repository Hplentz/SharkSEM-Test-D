var annotated_dup =
[
    [ "SharkSEM", "namespace_shark_s_e_m.html", [
      [ "Connection", "class_shark_s_e_m_1_1_connection.html", "class_shark_s_e_m_1_1_connection" ]
    ] ]
];